cd master1/ ; vagrant reload ; cd ../node1 ; vagrant reload  ; cd ../node2 ;vagrant reload ;cd .. 
