#!/bin/bash

# Generate ssh key for login to cluster nodes
sudo su -
echo "PermitRootLogin prohibit-password" >> /etc/ssh/sshd_config
ssh-keygen -t rsa -f /root/.ssh/id_rsa  -q -N ''
mkdir /home/vagrant/ssh-keys
cp /root/.ssh/id_rsa.pub /home/vagrant/ssh-keys/
chown -R vagrant:vagrant /home/vagrant/ssh-keys


#add the custom "/etc/hosts" file 
cat <<EOF > /etc/hosts 

127.0.0.1	localhost 
127.0.1.1	vagrant.vm	vagrant
192.168.0.20	master
192.168.0.21	node1
192.168.0.22	node2

EOF



#set local DNS
echo "DNS=192.168.0.5" | sudo tee -a /etc/systemd/resolved.conf 

#docker install
sudo apt update
sudo apt-get -y install docker.io git make curl wget libltdl7 libseccomp2 libffi-dev gawk chrony
sudo usermod -aG docker vagrant
sudo systemctl enable docker

#seting docker registry
sudo cat > /etc/docker/daemon.json <<EOF
{
"registry-mirrors": ["https://registry.osive.com"],
 "live-restore": true,
 "dns": ["192.168.0.5"]
}
EOF

sudo service docker restart


# Set NTP timezone
timedatectl set-timezone  Asia/Kolkata

# Configuring cephadm master node
sudo su - 
cd /root
curl --silent --remote-name --location https://github.com/ceph/ceph/raw/octopus/src/cephadm/cephadm
chmod +x cephadm
./cephadm add-repo --release octopus
./cephadm install
mkdir -p /etc/ceph
cephadm bootstrap --mon-ip 192.168.0.20
cephadm install ceph-common
