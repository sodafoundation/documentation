#!/bin/bash

#add the custom "/etc/hosts" file 

cat <<EOF > /etc/hosts 
192.168.0.55 kara.osive.lab
192.168.0.60 goku.osive.lab
192.168.0.210 master.k8s.osive.lab
192.168.0.211 node1.k8s.osive.lab
192.168.0.212 node2.k8s.osive.lab
192.168.0.213 node3.k8s.osive.lab

192.168.0.20  master.ceph.ryo.osive.lab
192.168.0.21  node1.ceph.ryo.osive.lab
192.168.0.22  node2.ceph.ryo.osive.lab
192.168.0.23  node3.ceph.ryo.osive.lab
192.168.0.24  node4.ceph.ryo.osive.lab

192.168.0.246 one.esxi.osive.lab

127.0.0.1	localhost node3
127.0.1.1	vagrant.vm	vagrant
EOF



#set local DNS
echo "DNS=192.168.0.5" | sudo tee -a /etc/systemd/resolved.conf 

# Change HOSTNAME
sudo hostnamectl set-hostname node3.ceph.ryo.osive.lab --static


#docker install
sudo apt update
sudo apt-get -y install docker.io git make curl wget libltdl7 libseccomp2 libffi-dev gawk chrony sshpass
sudo usermod -aG docker vagrant
sudo systemctl enable docker

#seting docker registry
sudo cat > /etc/docker/daemon.json <<EOF
{
"registry-mirrors": ["http://192.168.0.244:5000"],
 "live-restore": true,
 "dns": ["192.168.0.5"]
}
EOF

sudo service docker restart


# Set NTP timezone
timedatectl set-timezone  Asia/Kolkata

